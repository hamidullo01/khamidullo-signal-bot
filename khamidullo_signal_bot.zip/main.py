import logging
from aiogram import Bot, Dispatcher, executor, types
import aiohttp
import os

API_TOKEN = os.getenv("BOT_TOKEN")
bot = Bot(token=API_TOKEN)
dp = Dispatcher(bot)

# Languages
LANGS = {
    "uz": {
        "start": "🇺🇿 Assalomu alaykum! Signal olish uchun /signal buyrug‘ini bosing.",
        "signal": "📊 {symbol} Signali:
📈 Trend: {trend}
🔁 RSI: {rsi}
🚨 Signal: {advice}
📍 Narx: {price} USD
🕒 Vaqt: {time}"
    },
    "en": {
        "start": "🇬🇧 Welcome! To get a signal, use the /signal command.",
        "signal": "📊 {symbol} Signal:
📈 Trend: {trend}
🔁 RSI: {rsi}
🚨 Signal: {advice}
📍 Price: {price} USD
🕒 Time: {time}"
    }
}

user_lang = {}

@dp.message_handler(commands=["start"])
async def start_cmd(message: types.Message):
    lang = message.from_user.language_code
    user_lang[message.from_user.id] = lang if lang in LANGS else "en"
    await message.reply(LANGS[user_lang[message.from_user.id]]["start"])

@dp.message_handler(commands=["signal"])
async def signal_cmd(message: types.Message):
    lang = user_lang.get(message.from_user.id, "en")
    symbols = ["XAUUSD", "EURUSD", "BTCUSD"]
    responses = []

    async with aiohttp.ClientSession() as session:
        for symbol in symbols:
            price = await fetch_price(symbol, session)
            trend = "Bullish" if float(price) % 2 == 0 else "Bearish"  # Mock
            rsi = 72  # Static RSI mock
            advice = "BUY" if rsi < 30 else "SELL" if rsi > 70 else "WAIT"
            from datetime import datetime
            text = LANGS[lang]["signal"].format(
                symbol=symbol,
                trend=trend,
                rsi=rsi,
                advice=advice,
                price=price,
                time=datetime.utcnow().strftime("%Y-%m-%d %H:%M UTC")
            )
            responses.append(text)

    await message.reply("

".join(responses))

async def fetch_price(symbol, session):
    if symbol == "XAUUSD":
        url = "https://api.metals.live/v1/spot"
        async with session.get(url) as resp:
            data = await resp.json()
            return data[0]["gold"]
    elif symbol == "EURUSD":
        url = "https://api.exchangerate.host/latest?base=EUR&symbols=USD"
        async with session.get(url) as resp:
            data = await resp.json()
            return data["rates"]["USD"]
    elif symbol == "BTCUSD":
        url = "https://api.coindesk.com/v1/bpi/currentprice/BTC.json"
        async with session.get(url) as resp:
            data = await resp.json()
            return data["bpi"]["USD"]["rate_float"]
    return "0"

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    executor.start_polling(dp, skip_updates=True)
